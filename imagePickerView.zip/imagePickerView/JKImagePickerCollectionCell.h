//
//  JKImagePickerView.h
//
//  Created by Jack/Zark on 2019/5/10.
//  Copyright © Jack/Zark All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JKImagePickerModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface JKImagePickerCollectionCell : UICollectionViewCell

@property (nonatomic, assign) NSInteger item;
@property (nonatomic, strong) JKImagePickerModel *model;
@property (nonatomic, copy) void (^removeImageEvent)(NSInteger);

//获取imageView上的图片
- (UIImage *)getLocalImage;

@end

NS_ASSUME_NONNULL_END

//
//  JKImagePickerView.h
//
//  Created by Jack/Zark on 2019/5/10.
//  Copyright © Jack/Zark All rights reserved.
//

#import "JKImagePickerCollectionCell.h"
#import <UIImageView+WebCache.h>

@interface JKImagePickerCollectionCell () {
    
}

@property (weak, nonatomic) IBOutlet UIImageView *imageView;
@property (weak, nonatomic) IBOutlet UIImageView *statusIcon;
@property (weak, nonatomic) IBOutlet UIButton *removeBtn;

@end

@implementation JKImagePickerCollectionCell

- (void)setModel:(JKImagePickerModel *)model {
    _model = model;
    BOOL showStatus = NO;
    BOOL showRemoveBtn = NO;
    if (model.status == JKImageStatusOnline || model.status == JKImageStatusOnlineCanDelete) {//网络图片（可能是本地图片强行修改状态）
        if (model.image) {
            //假的 online。只展示图片！！不显示状态和删除按钮（本地上传完成，提交url参数成功后，如果仅展示图片，不允许编辑）
            _imageView.image = model.image;
        }else {
            NSString *imageUrl = model.imageUrlString;
            if (model.thumbImageUrlString) {
                imageUrl = model.thumbImageUrlString;
            }
            if (imageUrl) {
                NSURL *url = [NSURL URLWithString:imageUrl];
                [_imageView sd_setImageWithURL:url placeholderImage:[UIImage imageNamed:@"image_placeholder"]];
            }else {
                _imageView.image = [UIImage imageNamed:@"image_placeholder"];
            }
        }
        showRemoveBtn = (model.status == JKImageStatusOnlineCanDelete);
    }else if (model.status == JKImageStatusAddIcon) {//【+】添加图片按钮
        _imageView.image = [UIImage imageNamed:@"ic_photo_empty"];
    }else {//上传的图片
        _imageView.image = model.image;
        showStatus = YES;
        showRemoveBtn = YES;
        if (model.status == JKImageStatusNotUpload) {//未上传
            _statusIcon.image = [UIImage imageNamed:@"upload_image_status_0"];
        }else if (model.status == JKImageStatusUploadedSuccess) {//上传成功
            _statusIcon.image = [UIImage imageNamed:@"upload_image_status_1"];
        }else if (model.status == JKImageStatusUploadedFailed) {//上传失败
            _statusIcon.image = [UIImage imageNamed:@"upload_image_status_2"];
        }
    }
    _statusIcon.hidden = !showStatus;
    _removeBtn.hidden = !showRemoveBtn;
}

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    _imageView.userInteractionEnabled = YES;
    [_removeBtn setImage:[UIImage imageNamed:@"ic_delete"] forState:UIControlStateNormal];
}

- (IBAction)removeBtnClick:(id)sender {
    if (_removeImageEvent) {
        _removeImageEvent(_item);
    }
}

- (UIImage *)getLocalImage {
    return _imageView.image;
}

@end

//
//  JKImagePickerView.h
//
//  Created by Jack/Zark on 2019/5/10.
//  Copyright © Jack/Zark All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JKImagePickerViewLayoutConfig.h"

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSUInteger, ImageUploadHandleStatus) {
    ImageUploadHandleStatusAllUploadedSuccess = 0,
    ImageUploadHandleStatusPartFailedDonotReupload,
    ImageUploadHandleStatusPartFailedReupload,
};

@interface JKImagePickerView : UIView

//@property (nonatomic, copy) void (^addImageEvent)(void);
//@property (nonatomic, copy) void (^removeImageEvent)(NSInteger);
@property (nonatomic, copy) void (^zoomOutEvent)(NSInteger);

//当用户操作图片（添加、删除等）时，通知用户对变化处理。Self的subView layout已经处理好；
@property (nonatomic, copy) void (^dataSourceChangedEvent)(NSInteger);

//tryGetImageUrls之后的回调。
@property (nonatomic, copy) void (^getImageUrlsResult)(ImageUploadHandleStatus, NSString *);

//if YES, show the add image button. default is NO;
@property (nonatomic, assign) BOOL canAddImage;
//only used when canAddImage = YES.
//if albumAllowed = NO, only taking photo by a camera is allowed. if YES, choose photos from album is allowed.
@property (nonatomic, assign) BOOL albumAllowed;

@property (nonatomic, strong) NSString *image_name_prefix;

- (instancetype)initWithConfig:(JKImagePickerViewLayoutConfig *)config startPoint: (CGPoint)point;
///if null would ignore the input and reloaddata directly.
- (CGFloat)reloadDataWith: (nullable NSArray *)dataSource;

//配合getImageUrlsResult使用；如果部分图片上传失败，需要用户确认是否重新上传，所以需要异步获取urls；
- (void)tryGetImageUrls;

//调用此接口，将会把self内部全部的imageModel.status转成online；设置canAddImage = NO;
//适用于全部图片上传完成后，禁止修改图片。
- (void)translateLocalImageStatusToOnlinStatus;









#pragma mark - 浏览大图需要数据源
- (NSMutableArray *)copySourceImageModels;
//JKImageBrowserOriginImageInfoDelegate需要用到的
- (CGRect)getOriginFrameof:(NSInteger)item;

- (UIImage *)getImageof:(NSInteger)item;

@end

NS_ASSUME_NONNULL_END

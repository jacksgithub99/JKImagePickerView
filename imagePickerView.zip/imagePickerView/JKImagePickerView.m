//
//  JKImagePickerView.h
//
//  Created by Jack/Zark on 2019/5/10.
//  Copyright © Jack/Zark All rights reserved.
//

#import "JKImagePickerView.h"
#import "JKImagePickerCollectionCell.h"
#import "JKImagePickerModel.h"

#import <Photos/Photos.h>
#import <TZImagePickerController/TZImagePickerController.h>
#import <AssetsLibrary/AssetsLibrary.h>

#import "IQKeyboardManager.h"
#import "AliyunFileManager.h"
#import "JKHUDManager.h"
//保存近期上传图片的url
#import "JKImageUploadedUrlsCache.h"

@interface JKImagePickerView ()<UICollectionViewDataSource, UICollectionViewDelegate, UINavigationControllerDelegate, UIImagePickerControllerDelegate, TZImagePickerControllerDelegate> {
    UICollectionView *_collectionView;
    NSMutableArray *_imageModelArray;       //最后一个永远是【+】JKImageStatusAddIcon，需插入图片在其之前！
    
    JKImageUploadedUrlsCache *_imageUrlsCache;
    NSInteger is_uploading_image_count;
    
    NSLock *_lock;
}

@property (nonatomic, strong) JKImagePickerViewLayoutConfig *layoutConfig;

@property (nonatomic, strong) UIImagePickerController *imagePickerVC;

@end

@implementation JKImagePickerView

- (instancetype)initWithConfig:(JKImagePickerViewLayoutConfig *)config startPoint: (CGPoint)point {
    _layoutConfig = config;
    CGFloat height = config.itemHeight;
    self = [super initWithFrame:CGRectMake(point.x, point.y, config.width, height)];
    if (self) {
        is_uploading_image_count = 0;
        _imageModelArray = [[NSMutableArray alloc] initWithCapacity:config.maxItemCount + 1];
        _imageUrlsCache = [[JKImageUploadedUrlsCache alloc] init];
        
        _lock = [[NSLock alloc] init];
        
        JKImagePickerModel *addModel = [[JKImagePickerModel alloc] init];
        addModel.status = JKImageStatusAddIcon;
        [_imageModelArray addObject:addModel];
        //
        UICollectionViewFlowLayout *flowlayout = [[UICollectionViewFlowLayout alloc] init];
        flowlayout.itemSize = CGSizeMake(config.itemWidth, config.itemHeight);
        flowlayout.minimumInteritemSpacing = (config.itemSpacing - 1);
        flowlayout.minimumLineSpacing = (config.rowSpacing - 1);
        
        _collectionView = [[UICollectionView alloc] initWithFrame:CGRectMake(0, 0, config.width, height) collectionViewLayout:flowlayout];
        [self addSubview:_collectionView];
        
        UINib *cellNib = [UINib nibWithNibName:@"JKImagePickerCollectionCell" bundle:nil];
        [_collectionView registerNib:cellNib forCellWithReuseIdentifier:@"JKImagePickerCollectionCellID"];
        _collectionView.dataSource = self;
        _collectionView.delegate = self;
        _collectionView.scrollEnabled = NO;
        
        CGFloat grayValue = 1;//245/255.0;
        self.backgroundColor = [UIColor colorWithRed:grayValue green:grayValue blue:grayValue alpha:1];
        
        _collectionView.backgroundColor = [UIColor colorWithRed:grayValue green:grayValue blue:grayValue alpha:1];
    }
    return self;
}

#pragma mark - reloadData
//内部也调此接口  [self reloadData With:nil];
- (CGFloat)reloadDataWith: (NSArray *)dataSource {
    NSInteger count = 0;
    if (dataSource) {
        [_imageModelArray removeAllObjects];
        [_imageModelArray addObjectsFromArray:dataSource];
    }
    //
    JKImagePickerModel *lastModel = [_imageModelArray lastObject];
    if (_canAddImage) {
        if (lastModel.status != JKImageStatusAddIcon) {
            JKImagePickerModel *addModel = [[JKImagePickerModel alloc] init];
            addModel.status = JKImageStatusAddIcon;
            [_imageModelArray addObject:addModel];
        }
    }else {
        if (lastModel.status == JKImageStatusAddIcon) {
            [_imageModelArray removeLastObject];
        }
    }
    count = _imageModelArray.count;
    CGFloat height = [_layoutConfig viewHeightForItemCount:count];
    CGRect frame = self.frame;
    frame.size.height = height;
    self.frame = frame;
    _collectionView.frame = CGRectMake(0, 0, _layoutConfig.width, height);
    [_collectionView reloadData];
    return height;
}

- (UIImagePickerController *)imagePickerVC {
    UIImagePickerController *vc = [[UIImagePickerController alloc] init];
    vc.sourceType = UIImagePickerControllerSourceTypeCamera;
    vc.delegate = self;
    
    //    vc.navigationBar.barTintColor = self.
    
    return vc;
}

#pragma mark - task

- (void)takePhoto {
    AVAuthorizationStatus authStatus = [AVCaptureDevice authorizationStatusForMediaType: AVMediaTypeVideo];
    if (authStatus == AVAuthorizationStatusNotDetermined) {
        [AVCaptureDevice requestAccessForMediaType:AVMediaTypeVideo completionHandler:^(BOOL granted) {
            if (granted) {
                [self takePhotoAciton];
            }
        }];
    }else if (authStatus == AVAuthorizationStatusRestricted || authStatus == AVAuthorizationStatusDenied) {
        [self cameraDenied];
    }else {
        [self takePhotoAciton];
    }
}

- (void)requestPhtoLibAuthoifNeeded {
    PHAuthorizationStatus status = [PHPhotoLibrary authorizationStatus];
    if (status == PHAuthorizationStatusDenied || status == PHAuthorizationStatusRestricted) {
        [self photoLibraryDenied];
    }else if (status == PHAuthorizationStatusNotDetermined) {
        [PHPhotoLibrary requestAuthorization:^(PHAuthorizationStatus status) {
            if (status == PHAuthorizationStatusAuthorized) {
                [self actionAfterAuthorized];
            }
        }];
    }else {
        [self actionAfterAuthorized];
    }
}

- (void)actionAfterAuthorized {
    [self presentTZImagePickerController];
}

- (void)takePhotoAciton {
    if ([UIImagePickerController isSourceTypeAvailable:(UIImagePickerControllerSourceTypeCamera)]) {
        self.imagePickerVC.sourceType = UIImagePickerControllerSourceTypeCamera;
        self.imagePickerVC.modalPresentationStyle = UIModalPresentationOverCurrentContext;
        //        JKHUDManager.show()
        [self.viewContainingController presentViewController:self.imagePickerVC animated:YES completion:^{
            //           JKHUDManager.dismiss()
        }];
    }else {
        
    }
}

- (void)photoLibraryDenied {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"无法访问相册" message:@"请在iPhone的‘设置-隐私-相册’中允许访问相册‘" preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *cancel = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil];
    UIAlertAction *ok = [UIAlertAction actionWithTitle:@"设置" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
        NSURL *url = [NSURL URLWithString: UIApplicationOpenSettingsURLString];
        [[UIApplication sharedApplication] openURL:url];
    }];
    [alert addAction:ok];
    [alert addAction:cancel];
    [self.viewContainingController presentViewController:alert animated:YES completion:nil];
}

- (void)cameraDenied {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"无法使用相机" message:@"请在iPhone的‘设置-隐私-相机’中允许访问相机‘" preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *cancel = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil];
    UIAlertAction *ok = [UIAlertAction actionWithTitle:@"设置" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
        NSURL *url = [NSURL URLWithString: UIApplicationOpenSettingsURLString];
        [[UIApplication sharedApplication] openURL:url];
    }];
    [alert addAction:ok];
    [alert addAction:cancel];
    [self.viewContainingController presentViewController:alert animated:YES completion:nil];
}

- (void)presentTZImagePickerController {
    
    NSMutableArray *mArray = [[NSMutableArray alloc] initWithCapacity:3];
    NSInteger imageFromCameraCount = 0;
    NSInteger imageFromOnline = 0;
    for (JKImagePickerModel *model in _imageModelArray) {
        if (model.asset) {
            [mArray addObject:model.asset];
        }
        if (model.cameraImageIdentifier) {
            imageFromCameraCount++;
        }
        if (model.status == JKImageStatusOnline || model.status == JKImageStatusOnlineCanDelete) {
            imageFromOnline++;
        }
    }
    //最大可选图片总数 - 相机拍照图片数量 = 相册可选数量
    NSInteger remainCount = _layoutConfig.maxItemCount - imageFromCameraCount - imageFromOnline;
    if (remainCount > 0) {
        TZImagePickerController *tempMmagePickerVC = [[TZImagePickerController alloc] initWithMaxImagesCount:remainCount columnNumber:3 delegate:self pushPhotoPickerVc:YES];
        
        tempMmagePickerVC.selectedAssets = mArray;
        
        tempMmagePickerVC.allowPickingVideo = NO;
        tempMmagePickerVC.allowPickingOriginalPhoto = YES;
        tempMmagePickerVC.allowPickingGif = NO;
        
        tempMmagePickerVC.showSelectBtn = NO;
        tempMmagePickerVC.allowTakePicture = NO;
        
        [self.viewContainingController presentViewController:tempMmagePickerVC animated:YES completion:nil];
    }else {
        //，已拍照N张，最多可选N张图片
    }
}

#pragma mark - 浏览大图需要数据源
- (NSMutableArray *)copySourceImageModels {
    NSMutableArray *mArray = [[NSMutableArray alloc] init];
    for (JKImagePickerModel *model in _imageModelArray) {
        if (model.status != JKImageStatusAddIcon) {
            [mArray addObject:[model copy]];
        }
    }
    return mArray;
}

//JKImageBrowserOriginImageInfoDelegate需要用到的
- (CGRect)getOriginFrameof:(NSInteger)item {
    if (item >= _imageModelArray.count) {
        return CGRectZero;
    }
    UICollectionViewCell *cell = [_collectionView cellForItemAtIndexPath:[NSIndexPath indexPathForItem:item inSection:0]];
    return [cell.superview convertRect:cell.frame toView:nil];
}

- (UIImage *)getImageof:(NSInteger)item {
    if (item >= _imageModelArray.count) {
        return nil;
    }
    JKImagePickerCollectionCell *cell = (JKImagePickerCollectionCell *)[_collectionView cellForItemAtIndexPath:[NSIndexPath indexPathForItem:item inSection:0]];
    return [cell getLocalImage];
    
}

#pragma mark - dataSourceChagedInternally
- (void)dataSourceChagedInternally: (BOOL) dontUploadImage {
    [_imageUrlsCache syncronizeImageUploadStatusFromCacheTo:_imageModelArray];
    if (!dontUploadImage) {
        [self uploadImages];
    }
    dispatch_async(dispatch_get_main_queue(), ^{
        [self reloadDataWith:nil];//必须在_dataSourceChangedEvent之前；会影响(_imageModelArray.count)
        if (_dataSourceChangedEvent) {
            _dataSourceChangedEvent(_imageModelArray.count);
        }
    });
}

///用时间戳做id；每次拍照仅允许调用一次，否则时间戳不同
- (NSString *)generateCameraImageIdentifier {
    NSTimeInterval interval = [[NSDate date] timeIntervalSince1970];
    NSString *stampString = [NSString stringWithFormat:@"WS%lf", interval];
    stampString = [stampString stringByReplacingOccurrencesOfString:@"." withString:@"_"];
    NSInteger rand = arc4random()%10000;
    stampString = [NSString stringWithFormat:@"%@_random%zd", stampString, rand];
    return stampString;
}

#pragma mark - 获取图片url s
///尝试获取上传图片的url，但如果有上传失败的图片，则返回nil；并弹出重新上传alert。
- (void)tryGetImageUrls {
    NSString *images = @"";
    BOOL has_uploaded_failed_image = NO;
    for (JKImagePickerModel *model in _imageModelArray) {
        if (model.status == JKImageStatusNotUpload || model.status == JKImageStatusUploadedFailed) {
            has_uploaded_failed_image = YES;
        }else {
            if (model.status == JKImageStatusUploadedSuccess || model.status == JKImageStatusOnline || model.status == JKImageStatusOnlineCanDelete) {
                if (model.imageUrlString) {
                    images = [images stringByAppendingString:@","];
                    images = [images stringByAppendingString:model.imageUrlString];
                }
            }
        }
    }
    
    NSString *imageUrls = nil;
    if (images.length > 0) {
        imageUrls = [images substringFromIndex:1];
    }
    
    if (has_uploaded_failed_image) {
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"提示" message:@"有未上传成功的图片，重新上传图片？" preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction *ok = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            [self uploadImages];
            [self tryGetImageUrlsCallback:ImageUploadHandleStatusPartFailedReupload urls:imageUrls];
        }];
        UIAlertAction *cancel = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
            [self tryGetImageUrlsCallback:ImageUploadHandleStatusPartFailedDonotReupload urls:imageUrls];
        }];
        [alert addAction:ok];
        [alert addAction:cancel];
        [self.viewContainingController presentViewController:alert animated:YES completion:nil];
    }else {
        [self tryGetImageUrlsCallback:ImageUploadHandleStatusAllUploadedSuccess urls:imageUrls];
    }
}

- (void)tryGetImageUrlsCallback:(ImageUploadHandleStatus) uploadStatus urls:(NSString *) imageUrls {
    //如果没有上传成功的图片，则 imageUrls == @""
    if (_getImageUrlsResult != nil) {
        _getImageUrlsResult(uploadStatus, imageUrls);
    }
}

- (void)translateLocalImageStatusToOnlinStatus {
    self.canAddImage = NO;
    for (JKImagePickerModel *model in _imageModelArray) {
        if (model.status != JKImageStatusAddIcon) {
            model.status = JKImageStatusOnline;
        }
    }
//    [self dataSourceChagedInternally:NO];
    dispatch_async(dispatch_get_main_queue(), ^{
        [self reloadDataWith:nil];//必须在_dataSourceChangedEvent之前；会影响(_imageModelArray.count)
        if (_dataSourceChangedEvent) {
            _dataSourceChangedEvent(_imageModelArray.count);
        }
    });
}

#pragma mark - 上传图片
- (void)uploadImages {
    for (NSInteger i = 0; i < _imageModelArray.count; i++) {
        JKImagePickerModel *model = _imageModelArray[i];
        
        if (model.status == JKImageStatusNotUpload || model.status == JKImageStatusUploadedFailed) {
            //未上传成功
            AliyunFileManager *manager = [[AliyunFileManager alloc] init];
            if (_image_name_prefix) {
                manager.prefix = _image_name_prefix;
            }else {
                manager.prefix = @"";
            }

            manager.callback = ^(NSInteger code, NSString * desc) {
                NSLog(@"%@", [NSThread currentThread]);
                [self->_lock lock];
                self->is_uploading_image_count--;
                if (self->is_uploading_image_count == 0) {
                    dispatch_async(dispatch_get_main_queue(), ^{
                        [JKHUDManager dismiss];
                    });
                }
                [self->_lock unlock];
                JKImagePickerModel *statusModel = [[JKImagePickerModel alloc] init];
                if (model.asset) {
                    statusModel.asset = model.asset;
                }else {
                    statusModel.cameraImageIdentifier = model.cameraImageIdentifier;
                }
                NSLog(@"model：%@", model);
                if (code == 0) {
                    //上传成功
                    statusModel.status = JKImageStatusUploadedSuccess;
                    statusModel.imageUrlString = desc;
                    NSLog(@"---desc---%@", desc);
                }else {
                    //上传失败
                    dispatch_async(dispatch_get_main_queue(), ^{
                        [JKHUDManager showError_autoDis:@"图片上传失败！"];
                    });
                    statusModel.status = JKImageStatusUploadedFailed;
                }
                NSLog(@"---statusModel---%zd", statusModel.status);
                [self->_imageUrlsCache cacheStatus: statusModel];
                //刷新
                [self->_lock lock];
                if (self->is_uploading_image_count == 0) {
                    dispatch_async(dispatch_get_main_queue(), ^{
                        [self->_imageUrlsCache syncronizeImageUploadStatusFromCacheTo:self->_imageModelArray];
                        [self reloadDataWith:nil];//要保证canAddImage值在上传图片时不改变！如果要改变，必须在reloadData With之后调用_dataSourceChangedEvent
                    });
                }
                [self->_lock unlock];
            };
            
            if (model.assetIdentifier) {
                [manager uploadImage:model.image originId:model.assetIdentifier];
            }else if (model.cameraImageIdentifier) {
                [manager uploadImage:model.image originId:model.cameraImageIdentifier];
            }
            
            is_uploading_image_count++;
        }
    }
    //for 循环之外
    [self->_lock lock];
    if (is_uploading_image_count != 0) {
        [JKHUDManager showPlainText:@"正在上传图片..."];
    }
    [self->_lock unlock];
}

#pragma mark - <UICollectionViewDataSource, UICollectionViewDelegate>

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    NSInteger showCount = MIN(_imageModelArray.count, _layoutConfig.maxItemCount);
    return showCount;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    JKImagePickerCollectionCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"JKImagePickerCollectionCellID" forIndexPath:indexPath];
    cell.item = indexPath.item;
    JKImagePickerModel *model = _imageModelArray[indexPath.item];
    cell.model = model;
    cell.removeImageEvent = ^(NSInteger item) {
        [self->_imageModelArray removeObjectAtIndex:item];
        [self dataSourceChagedInternally: YES];
    };
    NSLog(@"3----------ok");
    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    [collectionView deselectItemAtIndexPath:indexPath animated:YES];
    
    NSLog(@"0000000000----------ok");
    
    JKImagePickerModel *model = _imageModelArray[indexPath.item];
    if (model.status == JKImageStatusAddIcon) {
        if (_canAddImage) {
            if (_albumAllowed) {
                UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"上传照片" message:nil preferredStyle:UIAlertControllerStyleActionSheet];
                
                UIAlertAction *action_takephoto = [UIAlertAction actionWithTitle:@"拍照" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
                    [self takePhoto];
                }];
                UIAlertAction *action_open_album = [UIAlertAction actionWithTitle:@"从相册获取" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
                    [self requestPhtoLibAuthoifNeeded];
                }];
                UIAlertAction *cancel = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil];
                [alert addAction:action_takephoto];
                [alert addAction:action_open_album];
                [alert addAction:cancel];
                [self.viewContainingController presentViewController:alert animated:YES completion:nil];
            }else {
                [self takePhoto];
            }
        }
    }else {
        if (_zoomOutEvent) {
            _zoomOutEvent(indexPath.item);
        }
    }
}

#pragma mark -  UINavigationControllerDelegate, UIImagePickerControllerDelegate

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<UIImagePickerControllerInfoKey,id> *)info {
    [picker dismissViewControllerAnimated:YES completion:nil];
    NSThread *thread = [NSThread currentThread];
    NSLog(@"%@", thread);
    
    UIImage *originImage = [info objectForKey:@"UIImagePickerControllerOriginalImage"];
    if (originImage) {
        JKImagePickerModel *model = [[JKImagePickerModel alloc] init];
        model.status = JKImageStatusNotUpload;
        model.image = originImage;
        model.cameraImageIdentifier = [self generateCameraImageIdentifier];
        [_imageModelArray insertObject:model atIndex:_imageModelArray.count - 1];
    }
    [self dataSourceChagedInternally: NO];
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker {
    [picker dismissViewControllerAnimated:YES completion:nil];
}

#pragma mark - TZImagePickerControllerDelegate

- (void)tz_imagePickerControllerDidCancel:(TZImagePickerController *)picker {
    
}

// 这个照片选择器会自己dismiss，当选择器dismiss的时候，会执行下面的代理方法
// 如果isSelectOriginalPhoto为YES，表明用户选择了原图
// 你可以通过一个asset获得原图，通过这个方法：[[TZImageManager manager] getOriginalPhotoWithAsset:completion:]
// photos数组里的UIImage对象，默认是828像素宽，你可以通过设置photoWidth属性的值来改变它
- (void)imagePickerController:(TZImagePickerController *)picker didFinishPickingPhotos:(NSArray<UIImage *> *)photos sourceAssets:(NSArray *)assets isSelectOriginalPhoto:(BOOL)isSelectOriginalPhoto infos:(NSArray<NSDictionary *> *)infos {
    
    NSThread *thread = [NSThread currentThread];
    NSLog(@"%@", thread);
    
    NSMutableArray *tempArray = [[NSMutableArray alloc] initWithCapacity:MAX(assets.count, 1)];
    if (photos.count == assets.count) {
        for (NSInteger i = 0; i < photos.count; i++) {
            JKImagePickerModel *model = [[JKImagePickerModel alloc] init];
            model.image = photos[i];
            model.asset = assets[i];
             model.status = JKImageStatusNotUpload; //dataSourceChagedInternally -> syncronizeImageUploadStatus
            [tempArray addObject:model];
        }
    }
    NSInteger orgCount = _imageModelArray.count;
    for (NSInteger i = orgCount - 1; i >= 0 ; i--) {
        JKImagePickerModel *model = _imageModelArray[i];
        if (model.asset || model.status == JKImageStatusAddIcon) {
            //除了相机拍照的图片，都清除掉。
            [_imageModelArray removeObjectAtIndex:i];
        }
    }
    //添加当前勾选的图片
    [_imageModelArray addObjectsFromArray:tempArray];
    //添加【+】按钮
    JKImagePickerModel *addModel = [[JKImagePickerModel alloc] init];
    addModel.status = JKImageStatusAddIcon;
    [_imageModelArray addObject:addModel];
    
    [self dataSourceChagedInternally: NO];
}

@end




//
//  JKImagePickerView.h
//
//  Created by Jack/Zark on 2019/5/10.
//  Copyright © Jack/Zark All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface JKImagePickerViewLayoutConfig : NSObject

///**************************尺寸布局***************************

///最大图片数量，默认9；
@property (nonatomic, assign) NSInteger maxItemCount;
///控件宽度，默认screen width
@property (nonatomic, assign) CGFloat width;
///每行图片数,默认3。最小1，最大6；
@property (nonatomic, readonly) NSInteger itemCountPerRow;

///必须同时设置2个参数，保证布局不冲突；请先设定_width的值，有冲突则不执行
- (void)setItemSpacing: (CGFloat)isp itemCountPerRow: (NSInteger)count;

///图片水平间距，默认8points
@property (nonatomic, readonly) CGFloat itemSpacing;

///行间距，默认8points
@property (nonatomic, assign) CGFloat rowSpacing;
///图片是否是正方形, default = YES;YES时自动计算高度，NO时可自定义高度；
@property (nonatomic, assign) BOOL makeItemSquare;
///图片宽度，自动计算
@property (nonatomic, readonly) CGFloat itemWidth;
///图片高度，默认=图片宽度 makeItemSquare = NO时可自定义
@property (nonatomic, assign) CGFloat itemHeight;

- (CGFloat)viewHeightForItemCount: (NSInteger)count;

@end

NS_ASSUME_NONNULL_END

//
//  JKImagePickerView.h
//
//  Created by Jack/Zark on 2019/5/10.
//  Copyright © Jack/Zark All rights reserved.
//

#import "JKImagePickerViewLayoutConfig.h"

@interface JKImagePickerViewLayoutConfig ()

@end

@implementation JKImagePickerViewLayoutConfig

- (instancetype)init {
    self = [super init];
    if (self) {
        [self initDefaultParameters];
    }
    return self;
}

- (void)initDefaultParameters {
    _maxItemCount = 9;
    _width = [UIScreen mainScreen].bounds.size.width;
    _itemSpacing = 8;
    _rowSpacing = 8;
    _makeItemSquare = YES;
    _itemCountPerRow = 3;
    [self caculateItemHeight];
}

///必须同时设置2个参数，保证布局不冲突；请先设定_width的值
- (void)setItemSpacing: (CGFloat)isp itemCountPerRow: (NSInteger)count {
    //最小图片宽度，固定为20；
    CGFloat minimumItemWidth = 20;
    //pickerView需要的最小宽度
    CGFloat countFloat = (CGFloat)count;
    CGFloat minimumWidth = minimumItemWidth*countFloat + isp*(countFloat - 1);
    if (minimumWidth < _width) {
        _itemSpacing = isp;
        _itemCountPerRow = MAX(count, 1);
        [self caculateItemHeight];
    }
}

- (void)caculateItemHeight {
    if (_makeItemSquare) {
        _itemHeight = self.itemWidth;
    }
}

- (CGFloat)itemWidth {
    NSInteger count = MAX(_itemCountPerRow, 1);
    CGFloat countFloat = (CGFloat)count;
    CGFloat spacingCount = MAX(countFloat - 1, 0);
    CGFloat itemWidth = (_width - _itemSpacing*spacingCount)/countFloat;
    return itemWidth;
}

- (void)setMaxItemCount:(NSInteger)maxItemCount {
    if (maxItemCount > 0 && maxItemCount < 100) {
        _maxItemCount = maxItemCount;
    }
}

- (void)setWidth:(CGFloat)width {
    if (width >= 50 && width < [UIScreen mainScreen].bounds.size.width*3) {
        _width = width;
        [self caculateItemHeight];
    }
}

- (void)setRowSpacing:(CGFloat)rowSpacing {
    if (rowSpacing >= 0 && rowSpacing < 200) {
        _rowSpacing = rowSpacing;
    }
}

- (void)setItemHeight:(CGFloat)itemHeight {
    if (!_makeItemSquare) {
        if (itemHeight >= 20 && itemHeight < 1000) {
            _itemHeight = itemHeight;
        }
    }
}

- (CGFloat)viewHeightForItemCount: (NSInteger)count {
    NSInteger leagalCount = MAX(count, 0);
    NSInteger showCount = MIN(leagalCount, _maxItemCount);;
    NSInteger rows_full = showCount/_itemCountPerRow;
    NSInteger extraRow = (showCount%_itemCountPerRow == 0) ? 0 : 1; //不满一行，算一行。
    NSInteger all_rows = rows_full + extraRow;//可能 == 0
    CGFloat all_rows_float = (CGFloat)all_rows;
    CGFloat row_spacing_count = MAX(all_rows_float - 1, 0);
    CGFloat viewHeight = _itemHeight*all_rows_float + _rowSpacing*row_spacing_count;
    return viewHeight;
}

@end

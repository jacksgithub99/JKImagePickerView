//
//  JKImagePickerView.h
//
//  Created by Jack/Zark on 2019/5/10.
//  Copyright © Jack/Zark All rights reserved.
//

#import <Foundation/Foundation.h>

#import "JKImagePickerModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface JKImageUploadedUrlsCache : NSObject

//把cache的状态同步到imageModelArray
- (void)syncronizeImageUploadStatusFromCacheTo: (NSArray *)imageModelArray;

//把cache的状态同步到imageModel
- (void)syncronizeImageUploadStatusFromCacheToModel: (JKImagePickerModel *)model;

//保存状态
- (void)cacheStatus:(JKImagePickerModel *) statusModel;
@end

NS_ASSUME_NONNULL_END

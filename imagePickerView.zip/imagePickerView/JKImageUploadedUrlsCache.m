//
//  JKImagePickerView.h
//
//  Created by Jack/Zark on 2019/5/10.
//  Copyright © Jack/Zark All rights reserved.
//

#import "JKImageUploadedUrlsCache.h"


@interface JKImageUploadedUrlsCache () {
    NSMutableArray *_uploadStatusArray;
    
}

@end

@implementation JKImageUploadedUrlsCache

- (instancetype)init
{
    self = [super init];
    if (self) {
        _uploadStatusArray = [[NSMutableArray alloc] init];
    }
    return self;
}

//把cache的状态同步到imageModelArray
- (void)syncronizeImageUploadStatusFromCacheTo: (NSArray *)imageModelArray {
    for (JKImagePickerModel *model_new in imageModelArray) {
        for (JKImagePickerModel *model_staus in _uploadStatusArray) {
            if ([model_new.intellectIdentifier  isEqualToString: model_staus.intellectIdentifier]) {
                model_new.status = model_staus.status;
                model_new.imageUrlString = model_staus.imageUrlString;
                break;//跳出内层循环
            }
        }
    }
}

//把cache的状态同步到imageModel
- (void)syncronizeImageUploadStatusFromCacheToModel: (JKImagePickerModel *)model {
    if (model.cameraImageIdentifier) {
        return; //相机拍照的，状态没有缓存
    }
    for (JKImagePickerModel *model_staus in _uploadStatusArray) {
        if ([model.intellectIdentifier  isEqualToString: model_staus.intellectIdentifier]) {
            model.status = model_staus.status;
            model.imageUrlString = model_staus.imageUrlString;
            break;
        }
    }
}

- (void)cacheStatus:(JKImagePickerModel *) statusModel {
    BOOL modelExist = NO;
    for (JKImagePickerModel *model in _uploadStatusArray) {
        if (model.asset) {
            if ([model.assetIdentifier isEqualToString:statusModel.assetIdentifier]) {
                modelExist = YES;
                model.status = statusModel.status;
                model.imageUrlString = statusModel.imageUrlString;
            }
        }else if (model.cameraImageIdentifier){
            //必须缓存 拍照图片 状态！因为所有的上传状态都必须从JKImageUploadedUrlsCache获取！！如果不缓存，则拍照图片的状态同步后仍然是notupload！！
            if ([model.cameraImageIdentifier isEqualToString:statusModel.cameraImageIdentifier]) {
                modelExist = YES;
                model.status = statusModel.status;
                model.imageUrlString = statusModel.imageUrlString;
            }
        }
    }
    if (!modelExist) {
        [_uploadStatusArray addObject: [statusModel copy]];
    }
}

@end
